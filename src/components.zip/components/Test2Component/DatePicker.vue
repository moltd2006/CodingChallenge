<template>
  <el-row :gutter="20">
    <el-col :span="8">
      <label>{{field.label}}</label>
    </el-col>
    <el-col :span="16">
      <el-date-picker
        v-model="date"
        type="date"
        placeholder="Pick a day"
        value-format="timestamp">
      </el-date-picker>
    </el-col>
  </el-row>
</template>
<script>
export default {
  name: 'DatePicker',
  props: {
    data: String,
    field: Object
  },
  computed: {
    date: {
      set (value) {
        this.$emit('handle-change', value)
      },
      get () {
        return this.data
      }
    }
  }
}
</script>
