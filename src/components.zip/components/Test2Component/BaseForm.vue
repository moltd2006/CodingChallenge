<template>
  <form>
    <div class="form-group" v-for="field in formEls" :key="field.value">
      <template v-if="field.type === 'Dropdown'">
        <component
          :is="field.type"
          :field="field"
          :data.sync="data[field.value]"
          :options="field.options"
          @handle-change="handleChange($event)" />
      </template>
      <template v-else>
        <component
          :is="field.type"
          :field="field"
          :data="data[field.value]" />
      </template>
    </div>
  </form>
</template>
<script>
import BaseInput from '@/components/Test2Component/BaseInput.vue'
import Dropdown from '@/components/Test2Component/Dropdown.vue'
import DatePicker from '@/components/Test2Component/DatePicker.vue'

export default {
  name: 'BaseForm',
  components: {
    BaseInput,
    Dropdown,
    DatePicker
  },
  props: ['formEls', 'data'],
  methods: {
    handleChange (value) {
      console.log(value)
    }
  }
}
</script>

<style scoped>
  * {
    -webkit-font-smoothing: antialiased;
  }
  *, :after, :before {
    box-sizing: border-box;
  }
  .el-row {
    margin-bottom: 15px;
    text-align: left;
  }

  .el-select {
    display:block;
  }
</style>
