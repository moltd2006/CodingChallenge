<template>
  <el-row :gutter="20">
    <el-col :span="8">
      <label>{{field.label}}</label>
    </el-col>
    <el-col :span="16">
      <el-select v-model="val.value" placeholder="Select">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
    </el-col>
  </el-row>
</template>
<script>
export default {
  name: 'Dropdown',
  props: {
    options: Array,
    data: Object,
    field: Object
  },
  computed: {
    val: {
      set (value) {
        this.$emit('handle-change', value)
      },
      get () {
        return this.data
      }
    }
  }
}
</script>
