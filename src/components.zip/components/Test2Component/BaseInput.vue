<template>
  <el-row :gutter="20">
    <el-col :span="8">
      <label>{{field.label}}</label>
    </el-col>
    <el-col :span="16">
      <el-input
        :placeholder="field.placeholder"
        v-model="value"
      />
    </el-col>
  </el-row>
</template>
<script>
export default {
  name: 'BaseInput',
  props: {
    data: String,
    field: Object
  },
  computed: {
    value: {
      set (value) {
        this.$emit('handle-change', value)
      },
      get () {
        return this.data
      }
    }
  }
}
</script>
