<template>
  <div>
    <h4>Render a datatable using test4.json</h4>
    <p>Note: Calculate Average value, Total value </p>

  </div>
</template>

<script>
import data from './JsonFiles/test4'

export default {
  name: 'Test4',
  component: {
  },
  data () {
    return {
      data: data
    }
  },
  methods: {
    total () {

    },
    average () {

    }
  }
}
</script>

<style scoped>

</style>
